// frontend/courses.js
document.addEventListener("DOMContentLoaded", () => {
  const coursesBody = document.getElementById("coursesBody");
  const enrollmentsList = document.getElementById("enrollmentsList");
  const errorEl = document.getElementById("coursesError");
  const logoutBtn = document.getElementById("logoutBtn");
  const studentNameSpan = document.getElementById("studentName");

  const student = getStudent();
  if (!student || !getToken()) {
    window.location.href = "index.html";
    return;
  }
  studentNameSpan.textContent = `Welcome, ${student.name}`;

  logoutBtn.addEventListener("click", () => {
    clearAuth();
    window.location.href = "index.html";
  });

  async function loadCourses() {
    try {
      errorEl.textContent = "";
      const courses = await apiRequest("/courses");
      coursesBody.innerHTML = "";
      courses.forEach((c) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${c.code}</td>
          <td>${c.title}</td>
          <td>${c.credits}</td>
          <td><button data-id="${c._id}">Enroll</button></td>  <!-- FIXED: c._id -->
  `       ;
        coursesBody.appendChild(tr);
      });
    } catch (err) {
      errorEl.textContent = err.message;
    }
  }

  async function loadEnrollments() {
    try {
      const enrollments = await apiRequest("/enrollments/my");
      enrollmentsList.innerHTML = "";
      enrollments.forEach((en) => {
        const li = document.createElement("li");
        li.textContent = `${en.course.code} - ${en.course.title}`;
        enrollmentsList.appendChild(li);
      });
    } catch (err) {
      errorEl.textContent = err.message;
    }
  }

  coursesBody.addEventListener("click", async (e) => {
    if (e.target.tagName === "BUTTON") {
      const courseId = e.target.getAttribute("data-id");
      try {
        await apiRequest("/enrollments", {
          method: "POST",
          body: JSON.stringify({ courseId }),
        });
        loadEnrollments();
      } catch (err) {
        errorEl.textContent = err.message;
      }
    }
  });

  loadCourses();
  loadEnrollments();
});
