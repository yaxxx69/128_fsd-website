// frontend/app.js
const API_BASE_URL = "http://localhost:5000/api";

function saveAuth(token, student) {
  localStorage.setItem("token", token);
  localStorage.setItem("student", JSON.stringify(student));
}

function getToken() {
  return localStorage.getItem("token");
}

function getStudent() {
  const s = localStorage.getItem("student");
  return s ? JSON.parse(s) : null;
}

function clearAuth() {
  localStorage.removeItem("token");
  localStorage.removeItem("student");
}

async function apiRequest(path, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || "Request failed");
  }
  return data;
}
