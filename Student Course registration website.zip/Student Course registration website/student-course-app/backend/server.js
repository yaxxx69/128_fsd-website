// backend/server.js - FIXED VERSION (no next() callback)
require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/student_course_app")
  .then(() => console.log("✅ MongoDB connected"))
  .catch(err => {
    console.error("❌ MongoDB error:", err.message);
    process.exit(1);
  });

// Student Schema (FIXED: async pre-save hook)
const studentSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true }
});

// FIXED: Use async function instead of next()
studentSchema.pre("save", async function() {
  if (!this.isModified("password")) return;
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

const Student = mongoose.model("Student", studentSchema);

// Course Schema
const courseSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  credits: { type: Number, default: 3 }
});
const Course = mongoose.model("Course", courseSchema);

// Enrollment Schema
const enrollmentSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
  course: { type: mongoose.Schema.Types.ObjectId, ref: "Course", required: true }
});
enrollmentSchema.index({ student: 1, course: 1 }, { unique: true });
const Enrollment = mongoose.model("Enrollment", enrollmentSchema);

// Auth middleware
const authMiddleware = (req, res, next) => {
  try {
    const token = req.header("Authorization")?.replace("Bearer ", "");
    if (!token) return res.status(401).json({ message: "No token" });
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "secretkey");
    req.user = { id: decoded.id };
    next();
  } catch (err) {
    res.status(401).json({ message: "Invalid token" });
  }
};

// Routes
app.post("/api/auth/register", async (req, res) => {
  try {
    console.log("📝 Register:", req.body);
    const { name, email, password } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields required" });
    }

    const exists = await Student.findOne({ email });
    if (exists) return res.status(400).json({ message: "Email exists" });

    const student = await Student.create({ name, email, password });
    const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET || "secretkey");

    console.log("✅ Student registered:", student.email);
    res.status(201).json({
      token,
      student: { id: student._id, name, email }
    });
  } catch (err) {
    console.error("❌ Register error:", err.message);
    res.status(500).json({ message: err.message });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    console.log("🔑 Login:", req.body.email);
    const { email, password } = req.body;
    const student = await Student.findOne({ email });
    
    if (!student || !(await bcrypt.compare(password, student.password))) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET || "secretkey");
    res.json({
      token,
      student: { id: student._id, name: student.name, email }
    });
  } catch (err) {
    console.error("❌ Login error:", err.message);
    res.status(500).json({ message: err.message });
  }
});

app.get("/api/courses", async (_req, res) => {
  try {
    const courses = await Course.find();
    res.json(courses);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.post("/api/enrollments", authMiddleware, async (req, res) => {
  try {
    const { courseId } = req.body;
    const enrollment = await Enrollment.create({
      student: req.user.id,
      course: courseId
    });
    res.status(201).json(enrollment);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(400).json({ message: "Already enrolled" });
    }
    console.error("❌ Enrollment error:", err.message);
    res.status(500).json({ message: err.message });
  }
});

app.get("/api/enrollments/my", authMiddleware, async (req, res) => {
  try {
    const enrollments = await Enrollment.find({ student: req.user.id }).populate("course");
    res.json(enrollments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.get("/", (_req, res) => res.json({ message: "🚀 API running" }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🌐 Server on http://localhost:${PORT}`));
