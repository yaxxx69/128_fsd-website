// backend/seed.js
const mongoose = require("mongoose");

mongoose.connect("mongodb://127.0.0.1:27017/student_course_app");

const courseSchema = new mongoose.Schema({
    code: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    credits: { type: Number, default: 3 }
});
const Course = mongoose.model("Course", courseSchema);

async function seedCourses() {
    try {
        await Course.deleteMany({}); // Clear existing
        await Course.insertMany([
            { code: "CS101", title: "Intro to Programming", credits: 3 },
            { code: "MATH201", title: "Calculus II", credits: 4 },
            { code: "DL101", title: "Deep Learning", credits: 3 },
            { code: "WEB301", title: "Full Stack Web Dev", credits: 3 }
        ]);
        console.log("✅ Seeded 4 courses");
        mongoose.connection.close();
    } catch (err) {
        console.error("❌ Seed error:", err);
    }
}

seedCourses();
