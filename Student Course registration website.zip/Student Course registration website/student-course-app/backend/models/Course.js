// backend/models/Course.js
const mongoose = require("mongoose");

const courseSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true },
    title: { type: String, required: true },
    description: { type: String },
    credits: { type: Number, default: 3 },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Course", courseSchema);
