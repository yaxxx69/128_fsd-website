// backend/routes/enrollmentRoutes.js
const express = require("express");
const { enrollInCourse, getMyEnrollments } = require("../controllers/enrollmentController");
const { authMiddleware } = require("../controllers/authController");

const router = express.Router();

router.post("/", authMiddleware, enrollInCourse);
router.get("/my", authMiddleware, getMyEnrollments);

module.exports = router;
