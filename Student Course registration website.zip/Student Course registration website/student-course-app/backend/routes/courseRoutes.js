// backend/routes/courseRoutes.js
const express = require("express");
const {
  createCourse,
  getCourses,
  getCourseById,
  updateCourse,
  deleteCourse,
} = require("../controllers/courseController");
const { authMiddleware } = require("../controllers/authController");

const router = express.Router();

router.get("/", getCourses);
router.get("/:id", getCourseById);

// For simplicity, protect write operations (could be admin-only in future)
router.post("/", authMiddleware, createCourse);
router.put("/:id", authMiddleware, updateCourse);
router.delete("/:id", authMiddleware, deleteCourse);

module.exports = router;
