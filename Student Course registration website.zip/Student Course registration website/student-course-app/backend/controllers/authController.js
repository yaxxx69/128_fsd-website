// backend/controllers/authController.js
const jwt = require("jsonwebtoken");
const Student = require("../models/Student");

const generateToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET || "secretkey", { expiresIn: "7d" });

exports.registerStudent = async (req, res) => {
  try {
    console.log("Register attempt:", req.body); // ADD THIS
    const { name, email, password } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const exists = await Student.findOne({ email });
    if (exists) {
      return res.status(400).json({ message: "Email already registered" });
    }

    const student = await Student.create({ name, email, password });
    const token = generateToken(student._id);

    console.log("Student created:", student.email); // ADD THIS
    res.status(201).json({
      token,
      student: { id: student._id, name: student.name, email: student.email },
    });
  } catch (err) {
    console.error("Register error:", err); // ADD THIS - shows real error
    res.status(500).json({ message: err.message || "Server error" });
  }
};

// Keep other functions same...
exports.loginStudent = async (req, res) => {
  try {
    console.log("Login attempt:", req.body.email); // ADD THIS
    const { email, password } = req.body;
    const student = await Student.findOne({ email });
    if (!student || !(await student.matchPassword(password))) {
      return res.status(400).json({ message: "Invalid email or password" });
    }

    const token = generateToken(student._id);
    res.json({
      token,
      student: { id: student._id, name: student.name, email: student.email },
    });
  } catch (err) {
    console.error("Login error:", err); // ADD THIS
    res.status(500).json({ message: err.message || "Server error" });
  }
};

// Keep authMiddleware same...
