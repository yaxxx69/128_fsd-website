// backend/controllers/courseController.js
const Course = require("../models/Course");

exports.createCourse = async (req, res) => {
  try {
    const { code, title, description, credits } = req.body;
    const course = await Course.create({ code, title, description, credits });
    res.status(201).json(course);
  } catch {
    res.status(500).json({ message: "Error creating course" });
  }
};

exports.getCourses = async (_req, res) => {
  try {
    const courses = await Course.find();
    res.json(courses);
  } catch {
    res.status(500).json({ message: "Error fetching courses" });
  }
};

exports.getCourseById = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found" });
    res.json(course);
  } catch {
    res.status(500).json({ message: "Error fetching course" });
  }
};

exports.updateCourse = async (req, res) => {
  try {
    const course = await Course.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!course) return res.status(404).json({ message: "Course not found" });
    res.json(course);
  } catch {
    res.status(500).json({ message: "Error updating course" });
  }
};

exports.deleteCourse = async (req, res) => {
  try {
    const course = await Course.findByIdAndDelete(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found" });
    res.json({ message: "Course deleted" });
  } catch {
    res.status(500).json({ message: "Error deleting course" });
  }
};
